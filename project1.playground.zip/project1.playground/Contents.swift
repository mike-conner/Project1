// Create an array of dictionaries called players that contains the information for all the players in the league.
let players: [[String: Any]] = [["name": "Joe Smith",          "height": 42,  "experience": true,   "guardian": "Jim and Jan Smith"],
                                ["name": "Jill Tanner",        "height": 36,  "experience": true,   "guardian": "Clara Tanner"],
                                ["name": "Bill Bon",           "height": 43,  "experience": true,   "guardian": "Sara and Jenny Bon"],
                                ["name": "Eva Gordon",         "height": 45,  "experience": false,  "guardian": "Wendy and Mike Gordon"],
                                ["name": "Matt Gill",          "height": 40,  "experience": false,  "guardian": "Charles and Sylvia Gill"],
                                ["name": "Kimmy Stein",        "height": 41,  "experience": false,  "guardian": "Bill and Hillary Stein"],
                                ["name": "Sammy Adams",        "height": 42,  "experience": false,  "guardian": "Jeff Adams"],
                                ["name": "Karl Saygan",        "height": 36,  "experience": true,   "guardian": "Heather Bledsoe"],
                                ["name": "Suzane Greenberg",   "height": 43,  "experience": true,   "guardian": "Henrietta Dumas"],
                                ["name": "Sal Dali",           "height": 45,  "experience": false,  "guardian": "Gala Dali"],
                                ["name": "Joe Kavalier",       "height": 40,  "experience": false,  "guardian": "Sam and Elaine Kavalier"],
                                ["name": "Ben Finkelstein",    "height": 41,  "experience": false,  "guardian": "Aaron and Jill Finkelstein"],
                                ["name": "Diego Soto",         "height": 42,  "experience": true,   "guardian": "Robin and Sarika Soto"],
                                ["name": "Chloe Alaska",       "height": 36,  "experience": false,  "guardian": "David and Jamie Alaska"],
                                ["name": "Arnold Willis",      "height": 43,  "experience": false,  "guardian": "Claire Willis"],
                                ["name": "Phillip Helm",       "height": 45,  "experience": true,   "guardian": "Thomas Helm and Eva Jones"],
                                ["name": "Les Clay",           "height": 40,  "experience": true,   "guardian": "Wynonna Brown"],
                                ["name": "Herschel Krustofski","height": 41,  "experience": true,   "guardian": "Hyman and Rachel Krustofski"]]

// Create four empty arrays of dictionaries for the different teams we will be creating along with an array for the letters to the parents.
var teamDragons: [[String: Any]] = [[:]]
var teamSharks:  [[String: Any]] = [[:]]
var teamRaptors: [[String: Any]] = [[:]]
var letters:     [String] = []

// Create three string constants for the practice times
let teamDragonsPracticeTime: String = "March 17, 1pm"
let teamSharksPracticeTime: String  = "March 17, 3pm"
let teamRaptorsPracticeTime: String = "March 18, 1pm"

// Create a function to generate the guardian letters for each player.
func generateLettersUsing(playerInformation: [String: Any], practiceTime: String, teamName: String) {
    let letter: String = """
    ---------------------------------------------------------------------------------------------
    Hello \(playerInformation["guardian"]!),
    I am pleased to announce that your child, \(playerInformation["name"]!), has been placed on team \(teamName).
    Please have your child at practice on \(practiceTime).
    Thank you and welcome to the team! GO \(teamName)!
    
    Best regards,
    Soccer League Coordinator
    ---------------------------------------------------------------------------------------------
    """
    letters.append(letter)
}


// Temporary variables for sorting the teams by experience and keeping track of how many are on each team.
var teamSharksCountExperienced     = 0
var teamDragonsCountExperienced    = 0
var teamRaptorsCountExperienced    = 0
var teamSharksCountNotExperienced  = 0
var teamDragonsCountNotExperienced = 0
var teamRaptorsCountNotExperienced = 0

// Determine size of roster and run through a for loop that sorts players evenly between three teams based on experience.
let rosterSize: Int  = players.count-1

for player in 0...rosterSize {
    if players[player]["experience"] as! Bool == true {
        if teamDragonsCountExperienced == teamSharksCountExperienced && teamDragonsCountExperienced == teamRaptorsCountExperienced {
            teamDragons.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamDragonsPracticeTime, teamName: "Dragons")
            teamDragonsCountExperienced += 1
        } else if teamSharksCountExperienced == teamRaptorsCountExperienced {
            teamSharks.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamSharksPracticeTime, teamName: "Sharks")
            teamSharksCountExperienced += 1
        } else {
            teamRaptors.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamRaptorsPracticeTime, teamName: "Raptors")
            teamRaptorsCountExperienced += 1
        }
    } else {
        if teamDragonsCountNotExperienced == teamSharksCountNotExperienced && teamDragonsCountNotExperienced == teamRaptorsCountNotExperienced {
            teamDragons.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamDragonsPracticeTime, teamName: "Dragons")
            teamDragonsCountNotExperienced += 1
        } else if teamSharksCountNotExperienced == teamRaptorsCountNotExperienced {
            teamSharks.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamSharksPracticeTime, teamName: "Sharks")
            teamSharksCountNotExperienced += 1
        } else {
            teamRaptors.append(players[player])
            generateLettersUsing(playerInformation: players[player], practiceTime: teamRaptorsPracticeTime, teamName: "Raptors")
            teamRaptorsCountNotExperienced += 1
        }
    }
}


// Print out the contents of the array letters.
for letter in letters {
    print(letter)
}
